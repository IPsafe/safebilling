from django.contrib import admin

admin.site.index_template = 'sysmon/index.html'
